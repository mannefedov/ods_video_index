# -*- coding:utf-8 -*-
from flask import Flask, request, render_template
from flask_bootstrap import Bootstrap
import json, sys
import requests
import pickle
import numpy  as np


app = Flask(__name__)
bootstrap = Bootstrap(app)
data = pickle.load(open('lingbuzz_data.pkl', 'rb'))

@app.route('/')
def index():
    return render_template('index.html',name='index')

@app.route('/query/',methods=['GET'])
def query():
    if request.method == 'GET':
        has_result = 0
        error = 0
        q = request.args.get('q')
        start_index = request.args.get('start')
        # read engineID
        # f = open('data/engine.json')
        # s = json.load(f)

        # sn = 'engine_' + str(i+1)
        # key = s['engine'][i][sn]['key']
        # cx = s['engine'][i][sn]['cx']
        # engine_name = s['engine'][i][sn]['name']

        # # search request
        # url = "https://www.googleapis.com/customsearch/v1"
        # if start_index :
        #     query_string = {"key":key,"cx":cx,"num":"10","q":q,"start":start_index}
        # else :
        #     query_string = {"key":key,"cx":cx,"num":"10","q":q}
        # response = requests.request("GET", url, params=query_string)
        # json_data = json.loads(response.text)

        has_result = 1

        # try :
        #     # case 1: results
        #     if json_data['items']:
        #         has_result = 1
        #         break
        # except :
        #     # case 2: error
        #     try :
        #         json_data['error']
        #         if i == len(s['engine'])-1:
        #             error = 1
        #             # print json_data
        #             error_msg = 'error_code' +str(json_data['error']['code'])
        #             return render_template('index.html',q=q,error=error,error_msg=error_msg,engine_name=engine_name)
        #         else :
        #             continue
        #     # case 3: no result
        #     except :
        #         break

        search_info="Found 10"
        engine_name = 'ODS'
        current_start_index = 0
        page_index = 0

        similarities = cosine_distances(svd.transform(tfidf.transform([q])), index)
        cum_ids = defaultdict(list)
        for i,s in enumerate(similarities[0]):
            cum_ids[index2id[i]].append((i, s))
        id_with_max = [(idx, min(elements, key=lambda x: x[1])) for idx, elements in cum_ids.items()]
        id_with_max = sorted(id_with_max, key=lambda x: x[1][1])[:10]

        if id_with_max:
            # print "results"
            results = []
            has_previous = 0

            # current_start_index = json_data['queries']['request'][0]['startIndex']
            # page_index = (current_start_index-1)/10+1
            # print "page is : " + str(page_index)
            # if current_start_index == 1 :
            #     has_previous = 0
            #     search_info =  'About ' + json_data['searchInformation']['formattedTotalResults'] + ' results (' + json_data['searchInformation']['formattedSearchTime'] + ' seconds)'
            # else :
            #     has_previous = 1
            #     search_info =  "Page " + str(current_start_index/10+1) + ' of About ' + json_data['searchInformation']['formattedTotalResults'] + ' results (' + json_data['searchInformation']['formattedSearchTime'] + ' seconds)'
            # # print(items)
            items = np.random.choice(list(data.keys()), 10)

            for i in id_with_max:
                idx = i[0]
                snippet = texts[i[1][0]]
                title = id2title[idx]
                time = times[i[1][0]]
                url = 'https://youtu.be/{}?t={}'.format(idx, time)

                result = {"title" : title, "link" : url, 
                          "displayLink" : url, 
                          "snippet" : snippet}
                # try :
                #     for k in item['pagemap'].keys() :
                #         # print(typeof(k))
                #         if k == 'cse_thumbnail' :
                #             print('has thumbnail!')
                #             result["thumbnail"] = item['pagemap']['cse_thumbnail'][0]
                #             result["thumbnail"]["height"] = int(item['pagemap']['cse_thumbnail']            # current_start_index = json_data['queries']['request'][0]['startIndex']
            # page_index = (current_start_index-1)/10+1[0]['height'])
                # except Exception as e:
                #     print('%s : %s' % (Exception,e))
                results.append(result)
                result = {}
            return render_template('index.html',q=q,results=results,error=error,
                                    engine_name=engine_name,search_info=search_info,
                                    has_previous=has_previous,current_start_index=current_start_index,
                                    page_index=page_index)
        else:
            
            return render_template('index.html',q=q,error=error,engine_name=engine_name,search_info=search_info)
 


@app.errorhandler(404)
def not_found(error):
    return render_template('404.html'), 404

if __name__ == '__main__':
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.decomposition import TruncatedSVD
    from sklearn.metrics.pairwise import cosine_distances
    from collections import defaultdict

    tfidf = TfidfVectorizer(min_df=3)
    svd = TruncatedSVD(200)
    texts = pickle.load(open('../data/texts.pkl', 'rb'))
    index = svd.fit_transform(tfidf.fit_transform(texts))
    index2id = pickle.load(open('../data/index2id.pkl', 'rb'))
    id2title = pickle.load(open('../data/id2title.pkl', 'rb'))
    times = pickle.load(open('../data/times.pkl', 'rb'))
    app.run(debug = True)

